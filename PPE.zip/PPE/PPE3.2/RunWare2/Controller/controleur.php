<?php
require_once('../Model/modele.php');

class contact extends DB {

    function setAjouter($contact){
        $strSQL = "INSERT INTO contact (nom,tel,mail,mes) 
                    VALUES ('".$contact['nom']."', '".$contact['tel']."','".$contact['mail']."','".$contact['mes']."');";
        $add = $this->getRequete($strSQL);
        return $add;
      }

    
    //Dans le modele.php
    /*function listeProd() {
        $strSQL = $this->cnx->prepare("SELECT * FROM produit");
        $strSQL->execute();
        
        $requete = $strSQL->fetchAll(PDO::FETCH_ASSOC);
        return $requete;
    }*/
}
?>