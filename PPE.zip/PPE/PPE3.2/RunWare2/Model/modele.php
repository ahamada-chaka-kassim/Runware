<?php
class DB {
    private $cnx = null;

    function __construct() {
        $config = parse_ini_file('config.ini');

        $login  = $config['DB_LOGIN'];
        $passwd = $config['DB_PASSWORD'];
        $base   = $config['DB_NOM'];
        $host   = $config['DB_SERVEUR'];
        $type   = $config['DB_SGBD'];
        $dsn    = $type.':host='. $host.';dbname='. $base;

        $this->cnx = new PDO($dsn, $login, $passwd);

        if($this->cnx == false){
            echo "Erreur de connection";
            
        } else{
                echo "Connection reussit !!";
        }
    }



    function getRequete($strSQL){
        $this->resultat = $this->cnx->prepare($strSQL);
        $this->resultat->execute();
        return $this->resultat->fetchAll();
      }
      
    /*function __destruct() {
        if ($this->resultat!==null) { $this->resultat = null; }
        if ($this->cnx!==null) { $this->cnx = null; }
    }

    function Requete($strSQL, $tblValeur){
        $this->resultat = $this->cnx->prepare($strSQL);
        $this->resultat->execute($tblValeur);
        return $this->resultat->fetchAll();
    }
    
    function listeProd() {
        $strSQL = $this->cnx->prepare("SELECT * FROM produit");
        $strSQL->execute();
        
        $requete = $strSQL->fetchAll(PDO::FETCH_OBJ);
        return $requete;
    }*/
}
?>