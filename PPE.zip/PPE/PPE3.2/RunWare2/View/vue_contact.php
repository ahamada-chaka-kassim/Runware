<!DOCTYPE html>
<html lang="fr">
<?php
  
    if (isset($_REQUEST['action'])) {
      require "../Model/modele.php";
      require "../Controller/controleur.php";
      $contact = new contact();

      if ($_GET['action'] == 'ajouter') {
        $contact->setAjouter($_POST);
      } 

   }

   
   ?>
   
      
   <head> 
      <meta charset="utf-8">

      <link rel="stylesheet" href="../css/contact.css">
      <link rel="stylesheet" type="text/css" href="../css/bootstrap.min.css">
      <link rel="stylesheet" href="../css/style.css">
      <?php include "header.php" ?>
   </head>

   <body>
  
   
      <!-- block d'instruction-->
      <div class="contact-section">
         <h1>Contact</h1><br>
         <h2 class="container-fluid">N'hésitez pas à nous contacter si vous avez des questions.</h2><br><br>

         <!-- Envoie les données au formulaire çi dessus-->
         <form class="contact-form" action="vue_contact.php?action=ajouter" method="post">
            
            <input type="text" name="nom" class="contact-form-text" placeholder="Enter votre nom" >
            <input type="Telephone" name="tel" class="contact-form-text" placeholder="Entrer votre Telephone">
            <input type="Email" name="mail"class="contact-form-text" placeholder="Entrer votre mail">
            <textarea name="mes" class="contact-form-text" placeholder="Votre Message"></textarea>
            <input type="submit"name="envoyer" class="contact-form-btn" value="envoyer">
         </form>
      </div>
  
   </body>
</html> 