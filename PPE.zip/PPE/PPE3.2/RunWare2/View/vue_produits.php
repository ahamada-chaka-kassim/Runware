<html lang="fr">

	<head>
    <meta charset="UTF-8">

    <!--Lien vers le CSS et l'en-tête-->
    <link rel="stylesheet" type="text/css" href="../css/bootstrap.min.css">
    <link rel="stylesheet" href="../css/style.css">
    <link rel="stylesheet" href="../css/produits.css">

    <?php include "header.php" ?>
  </head>	

  <body>
      <br>
      <h5 class="container-fluid">Ici, vous pouvez retrouver nos différents produits en vente.</h5><br><br>
      
      <?php
        require_once('../Controller/controleur.php');
        
        $database = new DB();
        $listProd = $database->listeProd();

        echo "<div class='container-fluid'>";
          echo "<div class='row my-3'>";
            foreach($listProd as $row) { 
              echo "<div class='col-4'>";
                echo "<div class='card'";
                  echo "<div><img class='produit' src=>".$row->imgprod."</div>";
                echo "<div class='card-body'>";
                  echo "<h5 class='card-title'><small><a href='vue_pageProduit.php'>".$row->nomProd."</a></small></h5>";
                  echo "<p class='card-text'><strong class='text-danger'>".$row->prixProd." €"."</strong></p><br><br>";
                echo "</div>";
              echo "</div>";
            }
          echo "</div>";
        echo "</div>";


        echo "<div class='container'>";
          echo '<nav aria-label="Page navigation">';
            echo '<ul class="pagination justify-content-end">';
              echo '<li class="page-item"><a class="page-link" href="#">Précédent</a></li>';
              echo '<li class="page-item"><a class="page-link" href="#">1</a></li>';
              echo '<li class="page-item"><a class="page-link" href="#">2</a></li>';
              echo '<li class="page-item"><a class="page-link" href="#">3</a></li>';
              echo '<li class="page-item"><a class="page-link" href="#">Suivant</a></li>';
            echo '</ul>';
          echo '</nav>';
        echo "</div>";
      ?> 
      

  </body>
</html>