<!DOCTYPE html>
<html lang="fr">
<header> 
<meta charset="utf-8">
<link rel="stylesheet" href="contact.css">

   <title>RunWare</title>
   <meta name="viewport" content="width=device-width, initial-scale=1">
</header>
<body>

  <!-- block d'instruction-->
<div class="contact-section">

<h1>Contact</h1>
<div class="border"></div>

   <!-- Envoie les données au formulaire çi dessus-->
   <form class="contact-form" action="Contact.php" method="post">
      <input type="text" class="contact-form-text" placeholder="Enter votre nom" >
      <input type="Telephone" class="contact-form-text" placeholder="Entrer votre Telephone">
      <input type="Email"class="contact-form-text" placeholder="Entrer votre Email">
      <textarea class="contact-form-text" placeholder="Votre Message"></textarea>
      <input type="submit" class="contact-form-btn" value="envoyer">

          
    </form>
    </div>
  
</body>
</html> 