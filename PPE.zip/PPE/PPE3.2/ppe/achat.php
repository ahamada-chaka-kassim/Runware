<!DOCTYPE html>
<html lang="fr">
<header> 
<meta charset="utf-8">
<link rel="stylesheet" href="achat.css">

   <title>RunWare</title>
   <meta name="viewport" content="width=device-width, initial-scale=1">
</header>
<body>
    <h1>achat</h1>

    <div class ="achat">

        <table>
            <tr>
                <th>Produit</th>
                <th>Quantité</th>
                <th>Total</th>
            </tr>
            <tr>
                <td>
                    <div class= "achat-info">
                        <img src="background.jpg">
                        <div>
                            <p>image</p>
                            <small>prix:$0.05</small>
                            <br>
                            <a href="">supprimer</a>
                    </div>
                    </div>
                </td>
                <td><input type="numero" value ="1"></td>
                <td>$0.05</td>
            </tr>

            <tr>
                <td>
                    <div class= "achat-info">
                        <img src="background.jpg">
                        <div>
                            <p>image</p>
                            <small>prix:$0.20</small>
                            <br>
                            <a href="">supprimer</a>
                    </div>
                    </div>
                </td>
                <td><input type="numero" value ="1"></td>
                <td>$0.20</td>
            </tr>

            <tr>
                <td>
                    <div class= "achat-info">
                        <img src="background.jpg">
                        <div>
                            <p>image</p>
                            <small>prix:$0.10</small>
                            <br>
                            <a href="">supprimer</a>
                    </div>
                    </div>
                </td>
                <td><input type="numero" value ="1"></td>
                <td>$0.10</td>
            </tr>

        </table>
            
        <div class="prix-total"> 
            <table>
                <tr>
                    <td>prix total</td>
                    <td>$20.00</td>
                </tr>

                <tr>
                    <td>tax</td>
                    <td>$30.00</td>
                </tr>

                <tr>
                    <td>total</td>
                    <td>$50.00</td>
                </tr>
            </table>

        </div>



    </div>


</body>
</html> 