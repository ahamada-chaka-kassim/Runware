<!DOCTYPE html>
<html lang="fr">
<meta charset="utf-8">

<link rel="stylesheet" href="index.css">

<header>
<title>RunWare</title>
<h1>RunWare</h1>
</header>



<h1 style="background-color:Violet;">Violet</h1>


<button>...</button>


<p>Faites votre choix</p>


<img src="background.jpg" alt="Flowers in Chania" width="460" height="345" style="width:100%;">



<p>Vous le savais </p>


<img src="background.jpg" alt="Flowers in Chania" width="460" height="345"style="width:100%;">







</body>
</html> 