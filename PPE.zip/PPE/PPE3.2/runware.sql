-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1:3306
-- Généré le : lun. 05 oct. 2020 à 08:59
-- Version du serveur :  8.0.21
-- Version de PHP : 7.4.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `runware`
--

-- --------------------------------------------------------

--
-- Structure de la table `categorie`
--

DROP TABLE IF EXISTS `categorie`;
CREATE TABLE IF NOT EXISTS `categorie` (
  `idCat` int NOT NULL AUTO_INCREMENT,
  `nomCateg` varchar(100) NOT NULL,
  PRIMARY KEY (`idCat`)
) ENGINE=InnoDB AUTO_INCREMENT=65 DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `categorie`
--

INSERT INTO `categorie` (`idCat`, `nomCateg`) VALUES
(1, 'Processeur'),
(2, 'Carte Graphique'),
(4, 'OS'),
(5, 'Clavier'),
(6, 'Souris'),
(7, 'Mémoire'),
(8, 'Carte Mère'),
(9, 'Alimentation'),
(10, 'Affichage'),
(11, 'Connectique'),
(12, 'Stockage HDD'),
(13, 'Stockage SSD');

-- --------------------------------------------------------

--
-- Structure de la table `commande`
--

DROP TABLE IF EXISTS `commande`;
CREATE TABLE IF NOT EXISTS `commande` (
  `idCommnd` int NOT NULL AUTO_INCREMENT,
  `idProd` int NOT NULL,
  `dateCommnd` date NOT NULL,
  PRIMARY KEY (`idCommnd`),
  KEY `idProd` (`idProd`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `contact`
--

DROP TABLE IF EXISTS `contact`;
CREATE TABLE IF NOT EXISTS `contact` (
  `idCont` int NOT NULL AUTO_INCREMENT,
  `idUtil` int NOT NULL,
  `msgCont` varchar(75) NOT NULL,
  PRIMARY KEY (`idCont`),
  KEY `idUtil` (`idUtil`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `produit`
--

DROP TABLE IF EXISTS `produit`;
CREATE TABLE IF NOT EXISTS `produit` (
  `idProd` int NOT NULL AUTO_INCREMENT,
  `idCat` int NOT NULL,
  `nomProd` varchar(50) NOT NULL,
  `prixProd` float NOT NULL,
  `descProd` varchar(500) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `imgProd` varchar(50) NOT NULL,
  PRIMARY KEY (`idProd`),
  KEY `idCat` (`idCat`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `produit`
--

INSERT INTO `produit` (`idProd`, `idCat`, `nomProd`, `prixProd`, `descProd`, `imgProd`) VALUES
(1, 1, 'AMD Athlon 240GE (3.5 GHz)', 76.99, 'AMD décline sa série de processeur AMD Athlon avec coeur graphique Radeon Vega avec le MAD Athlon 240GE. Ce processeur d\'entrée de gamme propose des performances avancées, une grande réactivité ainsi que des coeurs graphiques : l\'essentiel pour vous monter une configuration polyvalente !', 'photos/AMDAthlon240GE(3.5GHz).jpg'),
(2, 2, 'Gigabyte GeForce GTX 1650 D6 WINDFORCE OC', 179.96, ' La carte graphique Gigabyte GeForce GTX 1650 D6 WINDFORCE OC dotée de l\'architecture Turing se place comme remplaçante idéale de votre ancienne carte graphique. Derrière cette dénomination, profitez des performances de la nouvelle architecture de Nvidia ainsi que du passage à la mémoire GDDR6. La GTX 1650 sera votre meilleure alliée si vous cherchez à renouveler votre matériel gaming ou même à vous acheter votre première carte dédiée aux jeux vidéos.', 'photos/geforcegtx1650.jpg');

-- --------------------------------------------------------

--
-- Structure de la table `utilisateur`
--

DROP TABLE IF EXISTS `utilisateur`;
CREATE TABLE IF NOT EXISTS `utilisateur` (
  `idUtil` int NOT NULL AUTO_INCREMENT,
  `idCommnd` int NOT NULL,
  `civiliteUtil` char(1) NOT NULL,
  `pseudUtil` varchar(30) NOT NULL,
  `mdpUtil` varchar(30) NOT NULL,
  `nomUtil` varchar(25) NOT NULL,
  `pnomUtil` varchar(25) NOT NULL,
  `naissUtil` date NOT NULL,
  `mailUtil` varchar(30) NOT NULL,
  `numUtil` int NOT NULL,
  `addrFactUtil` varchar(30) NOT NULL,
  `addrLivrUtil` varchar(30) NOT NULL,
  PRIMARY KEY (`idUtil`),
  KEY `idCommnd` (`idCommnd`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Contraintes pour les tables déchargées
--

--
-- Contraintes pour la table `commande`
--
ALTER TABLE `commande`
  ADD CONSTRAINT `commande_ibfk_1` FOREIGN KEY (`idProd`) REFERENCES `produit` (`idProd`);

--
-- Contraintes pour la table `contact`
--
ALTER TABLE `contact`
  ADD CONSTRAINT `contact_ibfk_1` FOREIGN KEY (`idUtil`) REFERENCES `utilisateur` (`idUtil`);

--
-- Contraintes pour la table `produit`
--
ALTER TABLE `produit`
  ADD CONSTRAINT `produit_ibfk_1` FOREIGN KEY (`idCat`) REFERENCES `categorie` (`idCat`);

--
-- Contraintes pour la table `utilisateur`
--
ALTER TABLE `utilisateur`
  ADD CONSTRAINT `utilisateur_ibfk_1` FOREIGN KEY (`idCommnd`) REFERENCES `commande` (`idCommnd`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
