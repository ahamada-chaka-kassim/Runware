<?php
    require_once("./Model/modele.php");
    //Dans le modele.php

    /* class produits extends DB {

        function listeProd() {
        $strSQL = $this->cnx->prepare("SELECT * FROM produit");
        $strSQL->execute();
        
        $requete = $strSQL->fetchAll(PDO::FETCH_ASSOC);
        return $requete;
    }*/
    class Contact extends DB {

        function AddContact($tblc){
                 
            $strSQL = "INSERT INTO contact (nom,tel,mail,mes) VALUES (?,?,?,?) ";
            $tabValeur = array(
               $_POST['AddNom'],
               $_POST['AddTel'],
               $_POST['AddMail'], 
               $_POST['AddMes']
            );
            
            $ins = $this->Requete($strSQL, $tabValeur);
            return $ins;
    
              
              
                } 
        }    


?> 