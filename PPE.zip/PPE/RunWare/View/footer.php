<html lang="fr">
<link rel="stylesheet" href="./css/footer.css">

<footer>
    <hr>
    <p>&copy; RunWare | ProjetProfessionnelEncadré | 2020</a>
</footer>