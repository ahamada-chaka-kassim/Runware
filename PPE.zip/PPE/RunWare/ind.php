<?php 

try{
    if(isset($_REQUEST['action'])){
      require("./Controller/controleur.php");

    
      $contact = new Contact();
    
    if($_REQUEST['action'] == 'Contact') {
        
            require("View/vue_contact.php");
        }

    if($_REQUEST['action'] == 'Produits') {
        
            require("View/vue_produits.php");
        }

    if($_REQUEST['action'] == 'Acceuil') {
        
            require("View/vue_produits.php");
        } 
    
    if($_REQUEST['action'] == 'Panier') {
        
            require("View/vue_panier.php");
        } 
      
      if($_REQUEST['action'] == 'Envoyer') {
        
         $contact->AddContact($_POST);
         require("View/vue_contact.php");
    
        
    }  
    
    }else{ 
        require("index.php");
    }
      
    }catch(Exception $e){
      erreur($e->getMessage);
    }
  ?>