<html lang="fr">
  <head>
    <meta charset="UTF-8">
    <title>RunWare</title>

    <link rel="stylesheet" href="./css/bootstrap.min.css">
    <link rel="stylesheet" href="./css/style.css">
    <?php include './View/header.php' ?>
    <link rel="stylesheet" href="./css/articles_accueil.css">

    <script src="./js/jquery-3.5.1.slim.min.js"></script>
    <script src="./js/bootstrap.min.js"></script>
  </head>

  <body>
    <br><br>
    <div id="carouselPub" class="container carousel slide imgCarousel col-10" data-ride="carousel" data-interval="3000">
      <div class="carousel-inner">

        <div class="carousel-item active">
          <img src="./photos/pub1.jpg" class="d-block pub">
        </div>

        <div class="carousel-item">
          <img src="./photos/pub2.jpg" class="d-block pub">
        </div>

        <div class="carousel-item">
          <img src="./photos/pub4.jpg" class="d-block pub">
        </div>
      </div>

      <a href="#carouselPub" class="carousel-control-prev" role="button" data-slide="prev">
        <span class="carousel-control-prev-icon" aria-hidden="true"></span>
        <span class="sr-only">Précédent</span>
      </a>

      <a href="#carouselPub" class="carousel-control-next" role="button" data-slide="next">
        <span class="carousel-control-next-icon" aria-hidden="true"></span>
        <span class="sr-only">Suivant</span>
      </a>
    </div>

    <script>
      $('.carousel').carousel({
        pause: "null"
      })
    </script>


    <br><br>
    <h3 class="center">Des articles qui peuvent vous intéressez!</h3>


<div align="center">
<?php


$im=rand(1,5);
if($im==1){
  echo '<a href="View/vue_pageProduit.php?id=1"a><img src="./photos/AMDAthlon240GE(3.5GHz).jpg">';
}
if($im==2){
  echo '<a href="View/vue_pageProduit.php?id=2"a><img src="./photos/msi_a320m.jpg">';
}
if($im==3){
  echo '<a href="View/vue_pageProduit.php?id=3"a><img src="./photos/geforcegtx1650.jpg">';
}
if($im==4){
  echo '<a href="View/vue_pageProduit.php?id=4"a><img src="./photos/hdd2to.jpg">';
}
if($im==5){
  echo '<a href="View/vue_pageProduit.php?id=5"a><img src="./photos/AsusH410M-A.jpg">';
}

?>
</div>

  </body>
  <br><?php include "./view/footer.php" ?></br>
</html>